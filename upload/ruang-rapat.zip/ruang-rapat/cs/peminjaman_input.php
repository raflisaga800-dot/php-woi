<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['cs','admin'])) {
    die("Akses ditolak");
}

if (isset($_POST['simpan'])) {

    $nama       = $_POST['nama'];
    $ruangan    = $_POST['ruangan'];
    $tanggal    = $_POST['tanggal'];
    $mulai      = $_POST['mulai'];
    $selesai    = $_POST['selesai'];
    $keterangan = $_POST['keterangan'];
    $input_by   = $_SESSION['role'];

    // ===== UPLOAD FILE =====
    $fileName = null;

    if (!empty($_FILES['file']['name'])) {
        $folder = "../uploads/peminjaman/";

        // pastikan folder ada
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }

        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        $fileName = time().'_'.str_replace(' ','_',$_FILES['file']['name']);

        move_uploaded_file(
            $_FILES['file']['tmp_name'],
            $folder.$fileName
        );
    }

    // ===== INSERT DATABASE (FIXED) =====
    $sql = "INSERT INTO peminjaman 
        (nama_peminjam, ruangan, tanggal, waktu_mulai, waktu_selesai, keterangan, file_lampiran, input_by)
        VALUES
        ('$nama','$ruangan','$tanggal','$mulai','$selesai','$keterangan','$fileName','$input_by')
    ";

    mysqli_query($conn, $sql);

    echo "<script>alert('Peminjaman berhasil disimpan');</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Input Peminjaman</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<h2>Input Peminjaman Ruang Rapat</h2>

<form method="POST" enctype="multipart/form-data">
    <input name="nama" placeholder="Nama Peminjam" required>
    <input name="ruangan" placeholder="Ruangan" required>
    <input type="date" name="tanggal" required>
    <input type="time" name="mulai" required>
    <input type="time" name="selesai" required>
    <textarea name="keterangan" placeholder="Keterangan"></textarea>

    <label>Upload File (PDF/JPG)</label>
    <input type="file" name="file">

    <button name="simpan">Simpan</button>
</form>

</body>
</html>
