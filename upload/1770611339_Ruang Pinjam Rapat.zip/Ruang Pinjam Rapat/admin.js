checkAuth("admin");

let meetings = JSON.parse(localStorage.getItem("meetings")) || [];

function render() {
  const tbody = document.querySelector("#meetingTable tbody");
  tbody.innerHTML = "";

  meetings.forEach((m, i) => {
    const row = tbody.insertRow();
    row.innerHTML = `
            <td>${m.title}</td>
            <td>${m.date}</td>
            <td>${m.room}</td>
            <td>${m.participants}</td>
            <td>${m.materials}</td>
            <td><button onclick="editMeeting(${i})">Edit</button></td>
            <td><button onclick="deleteMeeting(${i})">Hapus</button></td>
        `;
  });
}

function editMeeting(i) {
  meetings[i].title = prompt("Judul", meetings[i].title);
  localStorage.setItem("meetings", JSON.stringify(meetings));
  render();
}

function deleteMeeting(i) {
  meetings.splice(i, 1);
  localStorage.setItem("meetings", JSON.stringify(meetings));
  render();
}

render();

// =========================
// AKUN RESEPSIONIS
// =========================
const usersKey = "users";
let users = JSON.parse(localStorage.getItem(usersKey)) || [];

// Render resepsionis
function renderReseps() {
  const tbody = document.querySelector("#resepsTable tbody");
  tbody.innerHTML = "";

  users
    .filter((u) => u.role === "resepsionis")
    .forEach((u) => {
      const row = tbody.insertRow();
      row.insertCell(0).innerText = u.username;
    });
}

renderReseps();

// Tambah resepsionis
document
  .getElementById("addResepsForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const username = document.getElementById("newUsername").value.trim();
    const password = document.getElementById("newPassword").value.trim();

    if (users.some((u) => u.username === username)) {
      alert("Username sudah ada");
      return;
    }

    users.push({
      username,
      password,
      role: "resepsionis",
    });

    localStorage.setItem(usersKey, JSON.stringify(users));
    renderReseps();
    this.reset();

    alert("Akun resepsionis berhasil dibuat");
  });
