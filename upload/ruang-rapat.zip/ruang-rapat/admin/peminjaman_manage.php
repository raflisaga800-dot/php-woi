<?php
session_start();
include "../config/db.php";

if ($_SESSION['role'] !== 'admin') {
    die("Akses ditolak");
}

if (isset($_GET['hapus'])) {
    mysqli_query($conn, "DELETE FROM peminjaman WHERE id=".$_GET['hapus']);
}

$data = mysqli_query($conn, "SELECT * FROM peminjaman ORDER BY tanggal DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Kelola Peminjaman</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<h2>Kelola Peminjaman</h2>

<table border="1">
<tr>
  <th>Nama</th>
  <th>Ruangan</th>
  <th>Tanggal</th>
  <th>Waktu</th>
  <th>Aksi</th>
</tr>

<?php while ($d = mysqli_fetch_assoc($data)) { ?>
<tr>
  <td><?= $d['nama_peminjam'] ?></td>
  <td><?= $d['ruangan'] ?></td>
  <td><?= $d['tanggal'] ?></td>
  <td><?= $d['waktu_mulai'] ?> - <?= $d['waktu_selesai'] ?></td>
  <td>
    <a href="?hapus=<?= $d['id'] ?>">Hapus</a>
  </td>
</tr>
<?php } ?>

</table>

<a href="dashboard.php">⬅ Kembali</a>

</body>
</html>
