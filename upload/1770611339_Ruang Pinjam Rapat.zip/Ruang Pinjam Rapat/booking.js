const BOOKING_KEY = "roomBookings";

// === RESEPSIONIS ===
const bookingForm = document.getElementById("bookingForm");
if (bookingForm) {
  bookingForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const ruang = document.getElementById("ruang").value;
    const tanggal = document.getElementById("tanggal").value;
    const jam = document.getElementById("jam").value;

    const bookings = JSON.parse(localStorage.getItem(BOOKING_KEY)) || [];

    bookings.push({
      ruang,
      tanggal,
      jam,
      status: "Menunggu CS",
    });

    localStorage.setItem(BOOKING_KEY, JSON.stringify(bookings));
    alert("Pesanan berhasil dikirim");
    bookingForm.reset();
  });
}

// === CS ===
const tableBody = document.querySelector("#bookingTable tbody");
if (tableBody) {
  function render() {
    const bookings = JSON.parse(localStorage.getItem(BOOKING_KEY)) || [];
    tableBody.innerHTML = "";

    bookings.forEach((b, i) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${b.ruang}</td>
        <td>${b.tanggal}</td>
        <td>${b.jam}</td>
        <td>${b.status}</td>
        <td>
          <button onclick="updateStatus(${i}, 'Diterima')">Terima</button>
          <button onclick="updateStatus(${i}, 'Ditolak')">Tolak</button>
        </td>
      `;
      tableBody.appendChild(tr);
    });
  }

  window.updateStatus = function (index, status) {
    const bookings = JSON.parse(localStorage.getItem(BOOKING_KEY)) || [];
    bookings[index].status = status;
    localStorage.setItem(BOOKING_KEY, JSON.stringify(bookings));
    render();
  };

  render();
  setInterval(render, 1000);
}
