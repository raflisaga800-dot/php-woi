checkAuth("resepsionis");

function render() {
  const meetings = JSON.parse(localStorage.getItem("meetings")) || [];
  const tbody = document.querySelector("#meetingTable tbody");
  tbody.innerHTML = "";
  meetings.forEach((m) => {
    const row = tbody.insertRow();
    row.innerHTML = `
            <td>${m.title}</td>
            <td>${m.date}</td>
            <td>${m.room}</td>
            <td>${m.participants}</td>
            <td>${m.materials}</td>
        `;
  });
}

render();
initChat("chatBoxReseps", "chatFormReseps", "messageReseps", "Resepsionis");
