<?php
include "../auth/middleware.php";
include "../config/db.php";

if (isset($_GET['hapus'])) {
  mysqli_query($conn, "DELETE FROM materi WHERE id=".$_GET['hapus']);
}

$q = mysqli_query($conn, "SELECT * FROM materi");
while ($m = mysqli_fetch_assoc($q)) {
  echo $m['judul']." ";
  echo "<a href='?hapus=".$m['id']."'>Hapus</a><br>";
}
