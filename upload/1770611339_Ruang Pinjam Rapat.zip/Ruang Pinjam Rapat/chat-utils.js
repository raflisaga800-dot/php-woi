function initChat(boxId, formId, inputId, sender, storageKey) {
  const box = document.getElementById(boxId);
  const form = document.getElementById(formId);
  const input = document.getElementById(inputId);

  function load() {
    return JSON.parse(localStorage.getItem(storageKey)) || [];
  }

  function save(data) {
    localStorage.setItem(storageKey, JSON.stringify(data));
  }

  function render() {
    const messages = load();
    box.innerHTML = "";
    messages.forEach((m) => {
      const p = document.createElement("p");
      p.innerHTML = `<b>${m.sender}:</b> ${m.text}`;
      box.appendChild(p);
    });
    box.scrollTop = box.scrollHeight;
  }

  render();

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    const messages = load();
    messages.push({ sender, text });
    save(messages);
    input.value = "";
    render();
  });

  setInterval(render, 1000);
}

/* ===== HAPUS HISTORY CHAT ===== */
function clearChat(chatKey) {
  if (confirm("Hapus semua history chat?")) {
    localStorage.removeItem(chatKey);
    location.reload();
  }
}
