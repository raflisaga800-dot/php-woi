<?php
$conn = mysqli_connect("localhost", "root", "", "db_ruang_rapat");
if (!$conn) {
  die("Database gagal konek");
}
