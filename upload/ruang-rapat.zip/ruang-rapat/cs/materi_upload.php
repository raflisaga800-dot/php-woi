<?php
// ================== SECURITY & DB ==================
session_start();
include "../config/db.php";

// Cek login
if (!isset($_SESSION['role'])) {
    header("Location: ../index.php");
    exit;
}

// Cek role CS
if ($_SESSION['role'] !== 'cs') {
    die("Akses ditolak");
}

// ================== UPLOAD LOGIC ==================
if (isset($_POST['upload'])) {

    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);

    // Folder tujuan (AMAN)
    $targetDir = __DIR__ . "/../uploads/materi/";

    // Buat folder kalau belum ada
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Ambil info file
    $fileName = basename($_FILES['file']['name']);
    $fileTmp  = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];

    // Ambil ekstensi
    $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    // Allowed file
    $allowed = ['pdf','doc','docx','ppt','pptx','zip'];

    if (!in_array($ext, $allowed)) {
        die("Format file tidak diizinkan");
    }

    // Limit size (10MB)
    if ($fileSize > 10 * 1024 * 1024) {
        die("Ukuran file terlalu besar (max 10MB)");
    }

    // Rename biar aman
    $newFileName = time() . "_" . $fileName;
    $targetFile  = $targetDir . $newFileName;

    // Upload file
    if (move_uploaded_file($fileTmp, $targetFile)) {

        // Simpan ke database
        $sql = "INSERT INTO materi (judul, deskripsi, file)
                VALUES ('$judul', '$deskripsi', '$newFileName')";
        mysqli_query($conn, $sql);

        echo "<script>alert('Materi berhasil diupload');</script>";

    } else {
        echo "<script>alert('Upload gagal');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Materi - CS</title>
</head>
<body>

<h2>Upload Materi (CS)</h2>

<form method="POST" enctype="multipart/form-data">
    <label>Judul</label><br>
    <input type="text" name="judul" required><br><br>

    <label>Deskripsi</label><br>
    <textarea name="deskripsi" rows="4"></textarea><br><br>

    <label>File Materi</label><br>
    <input type="file" name="file" required><br><br>

    <button type="submit" name="upload">Upload</button>
</form>

<br>
<a href="dashboard.php">⬅ Kembali</a>

</body>
</html>
