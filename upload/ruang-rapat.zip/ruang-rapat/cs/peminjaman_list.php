<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cs') {
    die("Akses ditolak");
}

$data = mysqli_query($conn, "SELECT * FROM peminjaman ORDER BY tanggal DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Peminjaman</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<h2>Daftar Peminjaman</h2>

<table border="1">
<tr>
  <th>Nama</th>
  <th>Ruangan</th>
  <th>Tanggal</th>
  <th>Waktu</th>
  <th>Keterangan</th>
</tr>

<?php while ($d = mysqli_fetch_assoc($data)) { ?>
<tr>
  <td><?= $d['nama_peminjam'] ?></td>
  <td><?= $d['ruangan'] ?></td>
  <td><?= $d['tanggal'] ?></td>
  <td><?= $d['waktu_mulai'] ?> - <?= $d['waktu_selesai'] ?></td>
  <td><?= $d['keterangan'] ?></td>
</tr>
<?php } ?>

</table>

<a href="dashboard.php">⬅ Kembali</a>

</body>
</html>
