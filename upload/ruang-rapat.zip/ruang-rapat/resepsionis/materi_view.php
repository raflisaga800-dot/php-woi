<?php
include "../auth/middleware.php";
include "../config/db.php";

$q = mysqli_query($conn, "SELECT * FROM materi");
while ($m = mysqli_fetch_assoc($q)) {
  echo "<h4>{$m['judul']}</h4>";
  echo "<p>{$m['deskripsi']}</p>";
  echo "<a href='../uploads/materi/{$m['file']}'>Download</a><hr>";
}
