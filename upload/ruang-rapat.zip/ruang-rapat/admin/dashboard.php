<?php include "../auth/middleware.php"; ?>
<h2>Dashboard Admin</h2>
<a href="materi_manage.php">Kelola Materi</a>
<a href="../auth/logout.php">Logout</a>
