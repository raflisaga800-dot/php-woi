<?php session_start();
if(isset($_SESSION['role'])){
    header("Location: ".$_SESSION['role']."/dashboard.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="login-container">
<form action="auth/login.php" method="POST">
<h2>Login</h2>
<input name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button>Login</button>
</form>
</div>

</body>
</html>
