<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cs') {
    die("Akses ditolak");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard CS</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<h2>Dashboard CS</h2>

<a href="peminjaman_input.php">➕ Input Peminjaman</a>
<a href="peminjaman_list.php">📄 Lihat Peminjaman</a>
<a href="../auth/logout.php">Logout</a>

</body>
</html>
