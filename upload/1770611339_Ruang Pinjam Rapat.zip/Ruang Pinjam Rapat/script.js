let users = JSON.parse(localStorage.getItem("users"));

if (!users) {
  users = [
    { username: "admin1", password: "123", role: "admin" },
    { username: "cs1", password: "123", role: "cs" },
    { username: "reseps1", password: "123", role: "resepsionis" },
  ];
  localStorage.setItem("users", JSON.stringify(users));
}

document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  const user = users.find(
    (u) => u.username === username && u.password === password
  );

  if (!user) {
    alert("Username atau password salah");
    return;
  }

  if (user.role === "admin") location.href = "admin.html";
  else if (user.role === "cs") location.href = "cs.html";
  else if (user.role === "resepsionis") location.href = "resepsionis.html";
});

document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();

  // ambil element input dengan BENAR
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");

  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  const user = users.find(
    (u) => u.username === username && u.password === password
  );

  if (!user) {
    alert("Username atau password salah");
    return;
  }

  // simpan session login
  localStorage.setItem("currentUser", JSON.stringify(user));

  // redirect sesuai role
  if (user.role === "admin") window.location.href = "admin.html";
  if (user.role === "cs") window.location.href = "cs.html";
  if (user.role === "resepsionis") window.location.href = "resepsionis.html";
});
