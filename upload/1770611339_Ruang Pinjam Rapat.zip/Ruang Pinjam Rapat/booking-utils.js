const BOOKING_KEY = "roomBookings";

function getBookings() {
  return JSON.parse(localStorage.getItem(BOOKING_KEY)) || [];
}

function saveBookings(data) {
  localStorage.setItem(BOOKING_KEY, JSON.stringify(data));
}

function addBooking(booking) {
  const bookings = getBookings();
  bookings.push(booking);
  saveBookings(bookings);
}

function updateBookingStatus(index, status) {
  const bookings = getBookings();
  bookings[index].status = status;
  saveBookings(bookings);
}
