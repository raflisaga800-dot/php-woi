<?php
session_start();
include "../config/db.php";

// proteksi login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'resepsionis') {
    header("Location: ../index.php");
    exit;
}

$data = mysqli_query($conn, "SELECT * FROM peminjaman ORDER BY tanggal DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Resepsionis</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<!-- TOP BAR -->
<div class="top-bar">
    <div>
        <h2>Dashboard Resepsionis</h2>
        <p>Data Peminjaman Ruang Rapat</p>
    </div>
    <a href="../auth/logout.php" class="btn-logout">Logout</a>
</div>

<!-- TABLE DATA -->
<table class="table-data">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Peminjam</th>
            <th>Ruangan</th>
            <th>Tanggal</th>
            <th>Waktu</th>
            <th>Keterangan</th>
            <th>File</th>
        </tr>
    </thead>
    <tbody>
        <?php $no=1; while($d = mysqli_fetch_assoc($data)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($d['nama_peminjam']) ?></td>
            <td><?= htmlspecialchars($d['ruangan']) ?></td>
            <td><?= $d['tanggal'] ?></td>
            <td><?= $d['waktu_mulai'] ?> - <?= $d['waktu_selesai'] ?></td>
            <td><?= htmlspecialchars($d['keterangan']) ?></td>
            <td>
                <?php if ($d['file_lampiran']) { ?>
                    <a href="../uploads/peminjaman/<?= $d['file_lampiran'] ?>" target="_blank">
                        Lihat File
                    </a>
                <?php } else { ?>
                    -
                <?php } ?>
            </td>
        </tr>
        <?php } ?>
    </tbody>
</table>

</body>
</html>
