function checkAuth(role) {
  const user = JSON.parse(localStorage.getItem("currentUser"));
  if (!user || user.role !== role) {
    alert("Akses ditolak");
    location.href = "index.html";
  }
}

function logout() {
  localStorage.removeItem("currentUser");
  location.href = "index.html";
}
