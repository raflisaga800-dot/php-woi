<?php
session_start();
include "../config/db.php";

if ($_SESSION['role'] !== 'admin') {
    die("Akses ditolak");
}

$id = $_GET['id'];

$data = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM peminjaman WHERE id=$id")
);

if (isset($_POST['update'])) {
    mysqli_query($conn, "
        UPDATE peminjaman SET
        nama_peminjam='$_POST[nama]',
        ruangan='$_POST[ruangan]',
        tanggal='$_POST[tanggal]',
        waktu_mulai='$_POST[mulai]',
        waktu_selesai='$_POST[selesai]',
        keterangan='$_POST[keterangan]'
        WHERE id=$id
    ");

    header("Location: peminjaman_manage.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Peminjaman</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<h2>Edit Peminjaman</h2>

<form method="POST">
    <input name="nama" value="<?= $data['nama_peminjam'] ?>"><br><br>
    <input name="ruangan" value="<?= $data['ruangan'] ?>"><br><br>
    <input type="date" name="tanggal" value="<?= $data['tanggal'] ?>"><br><br>
    <input type="time" name="mulai" value="<?= $data['waktu_mulai'] ?>">
    <input type="time" name="selesai" value="<?= $data['waktu_selesai'] ?>"><br><br>
    <textarea name="keterangan"><?= $data['keterangan'] ?></textarea><br><br>
    <button name="update">Update</button>
</form>

</body>
</html>
