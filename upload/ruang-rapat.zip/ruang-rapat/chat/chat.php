<?php
include "../auth/middleware.php";
include "../config/db.php";

if (isset($_POST['send'])) {
  $msg = $_POST['msg'];
  $role = $_SESSION['role'];
  mysqli_query($conn, "INSERT INTO chat (sender_role, message) VALUES ('$role','$msg')");
}

$q = mysqli_query($conn, "SELECT * FROM chat");
while ($c = mysqli_fetch_assoc($q)) {
  echo "<b>{$c['sender_role']}:</b> {$c['message']}<br>";
}
?>

<form method="POST">
  <input name="msg">
  <button name="send">Kirim</button>
</form>
