<?php
session_start();
if (!isset($_SESSION['role'])) {
  header("Location: /ruang-rapat/index.php");
  exit;
}
