document.addEventListener("DOMContentLoaded", function () {
  let meetings = JSON.parse(localStorage.getItem("meetings")) || [];

  function renderTable() {
    const tbody = document.querySelector("#meetingTable tbody");
    tbody.innerHTML = "";

    meetings.forEach((m) => {
      const row = tbody.insertRow();
      row.insertCell(0).innerText = m.title;
      row.insertCell(1).innerText = m.date;
      row.insertCell(2).innerText = m.room;
      row.insertCell(3).innerText = m.participants;

      const fileCell = row.insertCell(4);
      fileCell.innerText = m.fileName || "-";
    });
  }

  renderTable();

  document
    .getElementById("meetingForm")
    .addEventListener("submit", function (e) {
      e.preventDefault();

      const fileInput = document.getElementById("materialsFile");
      const file = fileInput.files[0];

      if (!file) {
        alert("Materi rapat wajib diupload");
        return;
      }

      const meeting = {
        title: document.getElementById("title").value,
        date: document.getElementById("date").value,
        room: document.getElementById("room").value,
        participants: document.getElementById("participants").value,

        // SIMPAN INFO FILE SAJA
        fileName: file.name,
      };

      meetings.push(meeting);
      localStorage.setItem("meetings", JSON.stringify(meetings));

      this.reset();
      renderTable();
    });
});
