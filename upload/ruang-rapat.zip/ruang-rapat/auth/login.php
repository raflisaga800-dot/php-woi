<?php
session_start();
include "../config/db.php";

$user = $_POST['username'];
$pass = md5($_POST['password']);

$q = mysqli_query($conn,"SELECT * FROM users WHERE username='$user' AND password='$pass'");
if(mysqli_num_rows($q)==1){
    $d=mysqli_fetch_assoc($q);
    $_SESSION['role']=$d['role'];
    header("Location: ../".$d['role']."/dashboard.php");
}else{
    echo "<script>alert('Login gagal');location='../index.php'</script>";
}
